package com.kaifrza.krdialer

import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioManager
import android.os.Bundle
import android.telecom.Call
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class InCallActivity : AppCompatActivity() {

    private lateinit var callerText: TextView
    private lateinit var stateText: TextView
    private lateinit var timerText: TextView
    private lateinit var answerButton: TextView
    private lateinit var rejectButton: TextView
    private lateinit var muteButton: TextView
    private lateinit var speakerButton: TextView
    private lateinit var endButton: TextView
    private var callback: Call.Callback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        updateUi()
    }

    override fun onResume() {
        super.onResume()
        registerCurrentCallback()
        updateUi()
    }

    override fun onPause() {
        unregisterCurrentCallback()
        super.onPause()
    }

    private fun buildUi() {
        val dark = true
        val bg = Color.rgb(9, 13, 18)
        val primary = Color.WHITE
        val secondary = Color.rgb(157, 168, 180)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
            setBackgroundColor(bg)
        }

        root.addView(TextView(this).apply {
            text = "KR Dialer"
            textSize = 14f
            setTextColor(secondary)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(40)
        ))

        callerText = TextView(this).apply {
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(primary)
            gravity = Gravity.CENTER
        }
        root.addView(callerText, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(64)
        ))

        stateText = TextView(this).apply {
            textSize = 16f
            setTextColor(secondary)
            gravity = Gravity.CENTER
        }
        root.addView(stateText)

        timerText = TextView(this).apply {
            text = " "
            textSize = 14f
            setTextColor(secondary)
            gravity = Gravity.CENTER
        }
        root.addView(timerText, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(42)
        ))

        val spacer = android.widget.Space(this)
        root.addView(spacer, LinearLayout.LayoutParams(
            1, 0, 1f
        ))

        val row1 = LinearLayout(this).apply {
            gravity = Gravity.CENTER
        }

        muteButton = actionButton("Mute")
        speakerButton = actionButton("Speaker")

        row1.addView(muteButton, buttonParams())
        row1.addView(speakerButton, buttonParams())
        root.addView(row1)

        val row2 = LinearLayout(this).apply {
            gravity = Gravity.CENTER
        }

        answerButton = actionButton("Answer")
        rejectButton = actionButton("Decline")

        row2.addView(rejectButton, buttonParams())
        row2.addView(answerButton, buttonParams())
        root.addView(row2)

        val bottomSpace = android.widget.Space(this)
        root.addView(bottomSpace, LinearLayout.LayoutParams(1, dp(22)))

        endButton = TextView(this).apply {
            text = "End call"
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = roundDrawable(Color.rgb(218, 61, 67), dp(30).toFloat())
            setOnClickListener { currentCall()?.disconnect() }
        }

        root.addView(endButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(62)
        ))

        muteButton.setOnClickListener {
            val audio = getSystemService(AudioManager::class.java)
            audio.isMicrophoneMute = !audio.isMicrophoneMute
            muteButton.text = if (audio.isMicrophoneMute) "Unmute" else "Mute"
        }

        speakerButton.setOnClickListener {
            val audio = getSystemService(AudioManager::class.java)
            audio.isSpeakerphoneOn = !audio.isSpeakerphoneOn
            speakerButton.text = if (audio.isSpeakerphoneOn) "Earpiece" else "Speaker"
        }

        answerButton.setOnClickListener { currentCall()?.answer(0) }
        rejectButton.setOnClickListener { currentCall()?.reject(false, null) }

        setContentView(root)
    }

    private fun actionButton(label: String): TextView {
        return TextView(this).apply {
            text = label
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = roundDrawable(Color.rgb(30, 38, 48), dp(26).toFloat())
        }
    }

    private fun buttonParams() = LinearLayout.LayoutParams(0, dp(58), 1f).apply {
        setMargins(dp(6), dp(6), dp(6), dp(6))
    }

    private fun currentCall(): Call? = CallController.getCurrentCall()

    private fun registerCurrentCallback() {
        val call = currentCall() ?: return
        val cb = object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                runOnUiThread { updateUi() }
            }
        }
        callback = cb
        call.registerCallback(cb)
    }

    private fun unregisterCurrentCallback() {
        callback?.let { currentCall()?.unregisterCallback(it) }
        callback = null
    }

    private fun updateUi() {
        val call = currentCall()

        if (call == null) {
            callerText.text = "No active call"
            stateText.text = "Ended"
            answerButton.visibility = TextView.GONE
            rejectButton.visibility = TextView.GONE
            endButton.visibility = TextView.GONE
            return
        }

        callerText.text = call.details.handle?.schemeSpecificPart ?: "Unknown"

        when (call.state) {
            Call.STATE_RINGING -> {
                stateText.text = "Incoming call"
                answerButton.visibility = TextView.VISIBLE
                rejectButton.visibility = TextView.VISIBLE
                endButton.visibility = TextView.GONE
            }

            Call.STATE_DIALING -> {
                stateText.text = "Dialing…"
                answerButton.visibility = TextView.GONE
                rejectButton.visibility = TextView.GONE
                endButton.visibility = TextView.VISIBLE
            }

            Call.STATE_CONNECTING -> {
                stateText.text = "Connecting…"
                answerButton.visibility = TextView.GONE
                rejectButton.visibility = TextView.GONE
                endButton.visibility = TextView.VISIBLE
            }

            Call.STATE_ACTIVE -> {
                stateText.text = "Active"
                answerButton.visibility = TextView.GONE
                rejectButton.visibility = TextView.GONE
                endButton.visibility = TextView.VISIBLE
            }

            Call.STATE_DISCONNECTING -> {
                stateText.text = "Ending…"
                answerButton.visibility = TextView.GONE
                rejectButton.visibility = TextView.GONE
                endButton.visibility = TextView.GONE
            }

            Call.STATE_DISCONNECTED -> {
                stateText.text = "Call ended"
                answerButton.visibility = TextView.GONE
                rejectButton.visibility = TextView.GONE
                endButton.visibility = TextView.GONE
            }

            else -> {
                stateText.text = "Connecting…"
            }
        }
    }

    private fun roundDrawable(color: Int, radius: Float): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
