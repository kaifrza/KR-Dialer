# KR-Dialer v0.4.1

Native Android dialer with the first polished UI milestone.

## v0.4 UI
- Real functional dial pad
- Large touch-friendly number keys
- Number input and backspace
- One-tap real SIM calling
- Dark/light theme toggle
- Default phone app shortcut
- Polished incoming-call screen
- Polished active/outgoing call screen
- Mute and speaker controls
- Responsive programmatic UI with no heavy UI library

## Baseline
v0.3.1 real SIM calling remains the functional foundation.

## Build
The repository workflow can extract this ZIP and build the APK with Gradle 8.13.
