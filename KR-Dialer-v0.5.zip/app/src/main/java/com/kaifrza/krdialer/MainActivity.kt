package com.kaifrza.krdialer

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val CALL_PERMISSION_REQUEST = 100
        private const val DIALER_ROLE_REQUEST = 200
        private const val PREFS = "kr_dialer"
        private const val DARK_MODE = "dark_mode"
    }

    private lateinit var numberInput: EditText
    private lateinit var themeButton: ImageButton

    private val keys = listOf(
        "1" to "",
        "2" to "ABC",
        "3" to "DEF",
        "4" to "GHI",
        "5" to "JKL",
        "6" to "MNO",
        "7" to "PQRS",
        "8" to "TUV",
        "9" to "WXYZ",
        "*" to "",
        "0" to "+",
        "#" to ""
    )

    private val inkLight = Color.rgb(23, 27, 35)
    private val mutedLight = Color.rgb(105, 112, 124)
    private val inkDark = Color.rgb(245, 247, 251)
    private val mutedDark = Color.rgb(161, 171, 187)
    private val accent = Color.rgb(43, 199, 116)

    override fun onCreate(savedInstanceState: Bundle?) {
        applySavedTheme()
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        buildUi()

        if (intent?.action == Intent.ACTION_DIAL) {
            numberInput.setText(intent.data?.schemeSpecificPart.orEmpty())
            numberInput.setSelection(numberInput.length())
        }
    }

    override fun onResume() {
        super.onResume()
        if (CallController.getCurrentCall() != null) {
            startActivity(
                Intent(this, InCallActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
            )
        }
    }

    private fun buildUi() {
        val dark = isDarkTheme()
        val bgTop = if (dark) Color.rgb(7, 12, 18) else Color.rgb(244, 248, 247)
        val bgBottom = if (dark) Color.rgb(13, 22, 30) else Color.rgb(225, 239, 235)
        val primary = if (dark) inkDark else inkLight
        val muted = if (dark) mutedDark else mutedLight

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(10))
            background = verticalGradient(bgTop, bgBottom)
        }

        // Header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val brand = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, dp(58), 1f)
        }

        brand.addView(TextView(this).apply {
            text = "KR"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(accent)
            letterSpacing = 0.18f
        })

        brand.addView(TextView(this).apply {
            text = "Dialer"
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(primary)
        })

        header.addView(brand)

        themeButton = ImageButton(this).apply {
            contentDescription = "Toggle theme"
            setImageResource(
                if (dark) android.R.drawable.ic_menu_day
                else android.R.drawable.ic_menu_month
            )
            setColorFilter(primary)
            background = glassDrawable(
                if (dark) Color.argb(42, 255, 255, 255)
                else Color.argb(105, 255, 255, 255),
                if (dark) Color.argb(65, 255, 255, 255)
                else Color.argb(125, 255, 255, 255)
            )
            setOnClickListener { toggleTheme() }
        }
        header.addView(themeButton, LinearLayout.LayoutParams(dp(50), dp(50)))

        val settings = ImageButton(this).apply {
            contentDescription = "Default phone app"
            setImageResource(android.R.drawable.ic_menu_manage)
            setColorFilter(primary)
            background = glassDrawable(
                if (dark) Color.argb(42, 255, 255, 255)
                else Color.argb(105, 255, 255, 255),
                if (dark) Color.argb(65, 255, 255, 255)
                else Color.argb(125, 255, 255, 255)
            )
            setOnClickListener { requestDefaultDialerRole() }
        }
        header.addView(settings, LinearLayout.LayoutParams(dp(50), dp(50)).apply {
            leftMargin = dp(8)
        })

        root.addView(header)

        // Number display glass panel
        val display = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = glassDrawable(
                if (dark) Color.argb(44, 255, 255, 255)
                else Color.argb(135, 255, 255, 255),
                if (dark) Color.argb(62, 255, 255, 255)
                else Color.argb(145, 255, 255, 255)
            )
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }

        val label = TextView(this).apply {
            text = "PHONE"
            textSize = 10f
            letterSpacing = 0.2f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(muted)
            gravity = Gravity.CENTER
        }
        display.addView(label)

        numberInput = EditText(this).apply {
            hint = "Enter number"
            textSize = 31f
            typeface = Typeface.create("sans", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setSingleLine(true)
            setTextColor(primary)
            setHintTextColor(muted)
            setBackgroundColor(Color.TRANSPARENT)
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            showSoftInputOnFocus = false
            includeFontPadding = false
            setPadding(0, dp(5), 0, dp(2))
        }
        display.addView(numberInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(58)
        ))

        val clear = TextView(this).apply {
            text = "Clear"
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setOnClickListener {
                numberInput.text.clear()
            }
        }
        display.addView(clear, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(26)
        ))

        root.addView(display, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(128)
        ).apply {
            topMargin = dp(10)
            bottomMargin = dp(8)
        })

        // Dial pad
        val keypad = GridLayout(this).apply {
            columnCount = 3
            rowCount = 4
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }

        keys.forEach { (number, letters) ->
            val key = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = glassDrawable(
                    if (dark) Color.argb(35, 255, 255, 255)
                    else Color.argb(118, 255, 255, 255),
                    if (dark) Color.argb(58, 255, 255, 255)
                    else Color.argb(135, 255, 255, 255)
                )
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    numberInput.append(number)
                }
            }

            val numberText = TextView(this).apply {
                text = number
                textSize = 25f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(primary)
                includeFontPadding = false
            }
            key.addView(numberText)

            if (letters.isNotEmpty()) {
                key.addView(TextView(this).apply {
                    text = letters
                    textSize = 8f
                    letterSpacing = 0.16f
                    gravity = Gravity.CENTER
                    setTextColor(muted)
                    includeFontPadding = false
                })
            }

            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(65)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            keypad.addView(key, params)
        }

        root.addView(keypad, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        // Bottom actions
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val delete = TextView(this).apply {
            text = "⌫"
            textSize = 25f
            gravity = Gravity.CENTER
            setTextColor(muted)
            background = glassDrawable(
                if (dark) Color.argb(34, 255, 255, 255)
                else Color.argb(110, 255, 255, 255),
                if (dark) Color.argb(52, 255, 255, 255)
                else Color.argb(120, 255, 255, 255)
            )
            setOnClickListener { deleteLastDigit() }
            setOnLongClickListener {
                numberInput.text.clear()
                true
            }
        }
        bottom.addView(delete, LinearLayout.LayoutParams(dp(54), dp(54)))

        val call = TextView(this).apply {
            text = "CALL"
            textSize = 13f
            letterSpacing = 0.16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = callDrawable()
            elevation = dp(8).toFloat()
            contentDescription = "Call"
            setOnClickListener { placeCall() }
        }

        bottom.addView(call, LinearLayout.LayoutParams(dp(86), dp(60)).apply {
            gravity = Gravity.CENTER
            leftMargin = dp(12)
            rightMargin = dp(12)
        })

        val voice = TextView(this).apply {
            text = "☎"
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(muted)
            background = glassDrawable(
                if (dark) Color.argb(34, 255, 255, 255)
                else Color.argb(110, 255, 255, 255),
                if (dark) Color.argb(52, 255, 255, 255)
                else Color.argb(120, 255, 255, 255)
            )
            contentDescription = "Call"
            setOnClickListener { placeCall() }
        }
        bottom.addView(voice, LinearLayout.LayoutParams(dp(54), dp(54)))

        root.addView(bottom, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(72)
        ))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
        }

        nav.addView(navItem("Recents", false, muted), LinearLayout.LayoutParams(
            0, dp(38), 1f
        ))
        nav.addView(navItem("Dial", true, accent), LinearLayout.LayoutParams(
            0, dp(38), 1f
        ))
        nav.addView(navItem("Contacts", false, muted), LinearLayout.LayoutParams(
            0, dp(38), 1f
        ))

        root.addView(nav)

        setContentView(root)
    }

    private fun navItem(text: String, selected: Boolean, color: Int): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = if (selected) 13f else 12f
            typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            gravity = Gravity.CENTER
            setTextColor(color)
        }
    }

    private fun placeCall() {
        val number = numberInput.text.toString().trim()
        if (number.isEmpty()) return

        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CALL_PHONE),
                CALL_PERMISSION_REQUEST
            )
            return
        }

        getSystemService(TelecomManager::class.java).placeCall(
            Uri.fromParts("tel", number, null),
            Bundle()
        )
    }

    private fun deleteLastDigit() {
        val value = numberInput.text.toString()
        if (value.isNotEmpty()) {
            numberInput.setText(value.dropLast(1))
            numberInput.setSelection(numberInput.length())
        }
    }

    private fun requestDefaultDialerRole() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)
            ) {
                startActivityForResult(
                    roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER),
                    DIALER_ROLE_REQUEST
                )
            }
        }
    }

    private fun toggleTheme() {
        val dark = !isDarkTheme()
        getSharedPreferences(PREFS, MODE_PRIVATE)
            .edit()
            .putBoolean(DARK_MODE, dark)
            .apply()

        AppCompatDelegate.setDefaultNightMode(
            if (dark) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun applySavedTheme() {
        AppCompatDelegate.setDefaultNightMode(
            if (isDarkTheme()) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun isDarkTheme(): Boolean =
        getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(DARK_MODE, true)

    private fun verticalGradient(top: Int, bottom: Int): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(top, bottom))

    private fun glassDrawable(fill: Int, stroke: Int): RippleDrawable {
        val base = GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(20).toFloat()
            setStroke(dp(1), stroke)
        }
        return RippleDrawable(
            android.content.res.ColorStateList.valueOf(Color.argb(45, 255, 255, 255)),
            base,
            null
        )
    }

    private fun callDrawable(): RippleDrawable {
        val base = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(31, 194, 110), Color.rgb(22, 153, 91))
        ).apply {
            cornerRadius = dp(30).toFloat()
            setStroke(dp(1), Color.argb(100, 255, 255, 255))
        }
        return RippleDrawable(
            android.content.res.ColorStateList.valueOf(Color.argb(55, 255, 255, 255)),
            base,
            null
        )
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    @Deprecated("Compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }
}
