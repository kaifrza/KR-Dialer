# KR-Dialer v0.5

Liquid UI redesign milestone.

## UI
- Glass/liquid inspired dial pad
- Layered translucent surfaces
- Soft gradients and borders
- Ripple/touch feedback
- Strong visual hierarchy
- Dark/light theme
- Large one-handed touch targets
- Cleaner number display
- Dedicated call action
- Redesigned incoming and active call screens

## Functional baseline
The real SIM calling and InCallService foundation from v0.3.1 remains intact.

## Build
Use the repository GitHub Actions workflow to extract this ZIP and build the APK.
