package com.kaifrza.krdialer

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    companion object {
        private const val CALL_PERMISSION_REQUEST = 100
        private const val DIALER_ROLE_REQUEST = 200
        private const val PREFS = "kr_dialer"
        private const val DARK_MODE = "dark_mode"
    }

    private lateinit var numberInput: EditText
    private lateinit var callButton: TextView
    private lateinit var themeButton: ImageButton

    private val keys = listOf(
        "1" to "",
        "2" to "ABC",
        "3" to "DEF",
        "4" to "GHI",
        "5" to "JKL",
        "6" to "MNO",
        "7" to "PQRS",
        "8" to "TUV",
        "9" to "WXYZ",
        "*" to "",
        "0" to "+",
        "#" to ""
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        applySavedTheme()
        super.onCreate(savedInstanceState)
        buildUi()

        if (intent?.action == Intent.ACTION_DIAL) {
            numberInput.setText(intent.data?.schemeSpecificPart.orEmpty())
            numberInput.setSelection(numberInput.length())
        }
    }

    override fun onResume() {
        super.onResume()
        if (CallController.getCurrentCall() != null) {
            startActivity(
                Intent(this, InCallActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
            )
        }
    }

    private fun applySavedTheme() {
        val dark = getSharedPreferences(PREFS, MODE_PRIVATE)
            .getBoolean(DARK_MODE, false)
        AppCompatDelegate.setDefaultNightMode(
            if (dark) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun buildUi() {
        val dark = isDarkTheme()
        val bg = if (dark) Color.rgb(11, 15, 20) else Color.rgb(247, 248, 250)
        val primaryText = if (dark) Color.WHITE else Color.rgb(20, 24, 30)
        val secondaryText = if (dark) Color.rgb(160, 169, 180) else Color.rgb(95, 103, 114)
        val card = if (dark) Color.rgb(25, 31, 39) else Color.WHITE

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(18), dp(14), dp(10))
        }

        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val title = TextView(this).apply {
            text = "KR Dialer"
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(primaryText)
        }

        val subtitle = TextView(this).apply {
            text = "Phone"
            textSize = 13f
            setTextColor(secondaryText)
        }

        titleBox.addView(title)
        titleBox.addView(subtitle)
        top.addView(titleBox)

        themeButton = ImageButton(this).apply {
            contentDescription = "Toggle theme"
            setImageResource(android.R.drawable.ic_menu_day)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(primaryText)
            setOnClickListener { toggleTheme() }
        }
        top.addView(themeButton, LinearLayout.LayoutParams(dp(48), dp(48)))

        val roleButton = ImageButton(this).apply {
            contentDescription = "Set as default phone app"
            setImageResource(android.R.drawable.ic_menu_preferences)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(primaryText)
            setOnClickListener { requestDefaultDialerRole() }
        }
        top.addView(roleButton, LinearLayout.LayoutParams(dp(48), dp(48)))

        root.addView(top)

        numberInput = EditText(this).apply {
            hint = "Enter number"
            textSize = 30f
            gravity = Gravity.CENTER
            setSingleLine(true)
            setTextColor(primaryText)
            setHintTextColor(secondaryText)
            setBackgroundColor(Color.TRANSPARENT)
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            showSoftInputOnFocus = false
            setPadding(dp(18), dp(8), dp(18), dp(4))
        }

        root.addView(numberInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(72)
        ))

        val actionRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), dp(4))
        }

        val erase = TextView(this).apply {
            text = "⌫"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(secondaryText)
            contentDescription = "Delete last digit"
            setOnClickListener { deleteLastDigit() }
            setOnLongClickListener {
                numberInput.text.clear()
                true
            }
        }
        actionRow.addView(erase, LinearLayout.LayoutParams(dp(56), dp(48)))

        val spacer = SpaceView(this)
        actionRow.addView(spacer, LinearLayout.LayoutParams(0, dp(1), 1f))

        val defaultText = TextView(this).apply {
            text = "Default phone app"
            textSize = 12f
            setTextColor(secondaryText)
            gravity = Gravity.CENTER_VERTICAL
        }
        actionRow.addView(defaultText)

        root.addView(actionRow)

        val keypad = GridLayout(this).apply {
            columnCount = 3
            rowCount = 4
            setPadding(dp(18), dp(4), dp(18), dp(8))
        }

        keys.forEach { (number, letters) ->
            val key = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setBackground(roundDrawable(card, dp(20).toFloat()))
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    numberInput.append(number)
                }
            }

            val main = TextView(this).apply {
                text = number
                textSize = 25f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                setTextColor(primaryText)
            }

            key.addView(main)

            if (letters.isNotEmpty()) {
                key.addView(TextView(this).apply {
                    text = letters
                    textSize = 9f
                    letterSpacing = 0.12f
                    gravity = Gravity.CENTER
                    setTextColor(secondaryText)
                })
            }

            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(76)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            }
            keypad.addView(key, params)
        }

        root.addView(keypad, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val bottom = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(4), dp(18), dp(18))
        }

        callButton = TextView(this).apply {
            text = "☎"
            textSize = 32f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = roundDrawable(Color.rgb(32, 177, 92), dp(32).toFloat())
            elevation = dp(4).toFloat()
            contentDescription = "Call"
            setOnClickListener { placeCall() }
        }

        bottom.addView(callButton, LinearLayout.LayoutParams(dp(72), dp(72)))
        root.addView(bottom)

        val footer = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(10))
        }

        footer.addView(TextView(this).apply {
            text = "Recents"
            textSize = 13f
            setTextColor(secondaryText)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, dp(40), 1f))

        footer.addView(TextView(this).apply {
            text = "Contacts"
            textSize = 13f
            setTextColor(secondaryText)
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(0, dp(40), 1f))

        root.addView(footer)

        setContentView(root)
    }

    private fun placeCall() {
        val number = numberInput.text.toString().trim()
        if (number.isEmpty()) return

        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CALL_PHONE),
                CALL_PERMISSION_REQUEST
            )
            return
        }

        val telecomManager = getSystemService(TelecomManager::class.java)
        telecomManager.placeCall(
            Uri.fromParts("tel", number, null),
            Bundle()
        )
    }

    private fun deleteLastDigit() {
        val value = numberInput.text.toString()
        if (value.isNotEmpty()) {
            numberInput.setText(value.dropLast(1))
            numberInput.setSelection(numberInput.length())
        }
    }

    private fun requestDefaultDialerRole() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)
            ) {
                startActivityForResult(
                    roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER),
                    DIALER_ROLE_REQUEST
                )
            }
        }
    }

    private fun toggleTheme() {
        val currentDark = isDarkTheme()
        getSharedPreferences(PREFS, MODE_PRIVATE)
            .edit()
            .putBoolean(DARK_MODE, !currentDark)
            .apply()

        AppCompatDelegate.setDefaultNightMode(
            if (!currentDark) AppCompatDelegate.MODE_NIGHT_YES
            else AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    private fun isDarkTheme(): Boolean {
        return getSharedPreferences(PREFS, MODE_PRIVATE)
            .getBoolean(DARK_MODE, false)
    }

    private fun roundDrawable(color: Int, radius: Float): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private class SpaceView(context: Context) : View(context)

    @Deprecated("Compatibility callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == DIALER_ROLE_REQUEST && resultCode == Activity.RESULT_OK) {
            // Role successfully granted; no extra action required.
        }
    }
}
