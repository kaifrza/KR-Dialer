# KR-Dialer v0.3

Native Android dialer foundation.

## Build
This project is intended to be built by GitHub Actions using the repository workflow.

## Important
The app is a real native Android project. It is not a WebView or Capacitor application.

## Current milestone
- Native Kotlin Android app
- SIM call placement foundation
- Default dialer role request
- InCallService foundation
- Incoming/outgoing call UI foundation
- Answer/reject/end controls
- Mute/speaker controls
- Android 10+ baseline
