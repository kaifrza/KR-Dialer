package com.kaifrza.krdialer

import android.telecom.Call
import java.lang.ref.WeakReference

object CallController {
    private var currentCallRef: WeakReference<Call>? = null
    private var currentState: Int = Call.STATE_NEW

    fun setCurrentCall(call: Call) {
        currentCallRef = WeakReference(call)
        currentState = call.state
    }

    fun updateState(state: Int) {
        currentState = state
    }

    fun getCurrentCall(): Call? = currentCallRef?.get()

    fun getCurrentState(): Int = currentState

    fun clearCall() {
        currentCallRef?.clear()
        currentCallRef = null
        currentState = Call.STATE_DISCONNECTED
    }
}
