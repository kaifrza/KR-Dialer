package com.kaifrza.krdialer

import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import android.Manifest
import android.content.pm.PackageManager

class MainActivity : AppCompatActivity() {

    companion object {
        private const val CALL_PERMISSION_REQUEST = 100
        private const val DIALER_ROLE_REQUEST = 200
    }

    private lateinit var numberInput: EditText
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }

        val title = TextView(this).apply {
            text = "KR Dialer"
            textSize = 28f
        }

        numberInput = EditText(this).apply {
            hint = "Phone number"
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }

        val callButton = Button(this).apply {
            text = "Call"
            setOnClickListener { placeCall() }
        }

        val roleButton = Button(this).apply {
            text = "Set as Default Phone App"
            setOnClickListener { requestDefaultDialerRole() }
        }

        statusText = TextView(this).apply {
            text = "Ready"
            textSize = 16f
        }

        layout.addView(title)
        layout.addView(numberInput)
        layout.addView(callButton)
        layout.addView(roleButton)
        layout.addView(statusText)
        setContentView(layout)

        if (intent?.action == Intent.ACTION_DIAL) {
            numberInput.setText(intent.data?.schemeSpecificPart.orEmpty())
        }
    }

    override fun onResume() {
        super.onResume()
        if (CallController.getCurrentCall() != null) {
            startActivity(
                Intent(this, InCallActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
            )
        }
    }

    private fun placeCall() {
        val number = numberInput.text.toString().trim()
        if (number.isEmpty()) {
            statusText.text = "Enter a phone number."
            return
        }

        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.CALL_PHONE),
                CALL_PERMISSION_REQUEST
            )
            return
        }

        val telecomManager = getSystemService(TelecomManager::class.java)
        val extras = Bundle()
        telecomManager.placeCall(Uri.fromParts("tel", number, null), extras)
        statusText.text = "Starting call…"
    }

    private fun requestDefaultDialerRole() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)
            ) {
                startActivityForResult(
                    roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER),
                    DIALER_ROLE_REQUEST
                )
            } else {
                statusText.text = "KR Dialer is already the default phone app."
            }
        }
    }

    @Deprecated("Handled for Android compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == DIALER_ROLE_REQUEST && resultCode == Activity.RESULT_OK) {
            statusText.text = "KR Dialer is now the default phone app."
        }
    }
}
