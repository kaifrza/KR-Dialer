package com.kaifrza.krdialer

import android.content.Intent
import android.telecom.Call
import android.telecom.InCallService

class KRInCallService : InCallService() {

    private val callbacks = mutableMapOf<Call, Call.Callback>()

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)

        CallController.setCurrentCall(call)

        val callback = object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                CallController.updateState(state)
                launchCallUi()
            }
        }

        callbacks[call] = callback
        call.registerCallback(callback)
        launchCallUi()
    }

    override fun onCallRemoved(call: Call) {
        callbacks.remove(call)?.let { call.unregisterCallback(it) }
        if (CallController.getCurrentCall() === call) {
            CallController.clearCall()
        }
        super.onCallRemoved(call)
    }

    private fun launchCallUi() {
        startActivity(
            Intent(this, InCallActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP
                )
            }
        )
    }
}
