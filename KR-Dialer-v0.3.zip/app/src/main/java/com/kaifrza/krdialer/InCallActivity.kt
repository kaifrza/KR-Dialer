package com.kaifrza.krdialer

import android.media.AudioManager
import android.os.Bundle
import android.telecom.Call
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class InCallActivity : AppCompatActivity() {

    private lateinit var stateText: TextView
    private lateinit var callerText: TextView
    private lateinit var muteButton: Button
    private lateinit var speakerButton: Button
    private var callback: Call.Callback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }

        callerText = TextView(this).apply { textSize = 24f }
        stateText = TextView(this).apply { textSize = 18f }

        val answer = Button(this).apply {
            text = "Answer"
            setOnClickListener { currentCall()?.answer(0) }
        }

        val reject = Button(this).apply {
            text = "Reject"
            setOnClickListener { currentCall()?.reject(false, null) }
        }

        muteButton = Button(this).apply {
            text = "Mute"
            setOnClickListener {
                val audio = getSystemService(AudioManager::class.java)
                audio.isMicrophoneMute = !audio.isMicrophoneMute
                text = if (audio.isMicrophoneMute) "Unmute" else "Mute"
            }
        }

        speakerButton = Button(this).apply {
            text = "Speaker"
            setOnClickListener {
                val audio = getSystemService(AudioManager::class.java)
                audio.isSpeakerphoneOn = !audio.isSpeakerphoneOn
                text = if (audio.isSpeakerphoneOn) "Earpiece" else "Speaker"
            }
        }

        val end = Button(this).apply {
            text = "End Call"
            setOnClickListener { currentCall()?.disconnect() }
        }

        root.addView(callerText)
        root.addView(stateText)
        root.addView(answer)
        root.addView(reject)
        root.addView(muteButton)
        root.addView(speakerButton)
        root.addView(end)

        setContentView(root)

        updateUi()
    }

    override fun onResume() {
        super.onResume()
        registerCurrentCallback()
        updateUi()
    }

    override fun onPause() {
        unregisterCurrentCallback()
        super.onPause()
    }

    private fun currentCall(): Call? = CallController.getCurrentCall()

    private fun registerCurrentCallback() {
        val call = currentCall() ?: return
        val cb = object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                runOnUiThread { updateUi() }
            }
        }
        callback = cb
        call.registerCallback(cb)
    }

    private fun unregisterCurrentCallback() {
        val call = currentCall()
        callback?.let { call?.unregisterCallback(it) }
        callback = null
    }

    private fun updateUi() {
        val call = currentCall()
        if (call == null) {
            callerText.text = "No active call"
            stateText.text = "Ended"
            return
        }

        callerText.text = call.details.handle?.schemeSpecificPart ?: "Unknown"
        stateText.text = when (call.state) {
            Call.STATE_RINGING -> "Ringing"
            Call.STATE_DIALING -> "Dialing"
            Call.STATE_CONNECTING -> "Connecting"
            Call.STATE_ACTIVE -> "Active"
            Call.STATE_DISCONNECTING -> "Disconnecting"
            Call.STATE_DISCONNECTED -> "Disconnected"
            else -> "Unknown"
        }

        val ringing = call.state == Call.STATE_RINGING
        findButton("Answer")?.visibility = if (ringing) View.VISIBLE else View.GONE
        findButton("Reject")?.visibility = if (ringing) View.VISIBLE else View.GONE
    }

    private fun findButton(label: String): Button? {
        val root = window.decorView.findViewById<View>(android.R.id.content) ?: return null
        return findButtonRecursive(root, label)
    }

    private fun findButtonRecursive(view: View, label: String): Button? {
        if (view is Button && view.text == label) return view
        if (view is android.view.ViewGroup) {
            for (i in 0 until view.childCount) {
                findButtonRecursive(view.getChildAt(i), label)?.let { return it }
            }
        }
        return null
    }
}
