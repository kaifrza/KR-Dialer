# KR-Dialer v0.7

Phone-app UI and data milestone.

## UI
- Clean Phone branding without repetitive KR labels
- Liquid/glass visual system
- Dialer/keypad
- Recents screen
- Contacts screen
- Search contacts
- Call action from recents and contacts
- Dark/light theme
- Responsive mobile layout

## Native functionality
- Real SIM calling through TelecomManager
- Real recent calls from Android CallLog
- Real contacts from Android ContactsProvider
- Runtime permissions for CALL_PHONE, READ_CALL_LOG and READ_CONTACTS
- Default dialer role request
- Existing InCallService remains native

## SPCK
The frontend lives in `app/src/main/assets/www/`.
Copy `www/` into SPCK and open `index.html` for UI preview.
Browser/SPCK mode intentionally shows preview behavior for native-only actions.
