const $=s=>document.querySelector(s),$$=s=>document.querySelectorAll(s);
const number=$("#number"),toast=$("#toast");
function native(name,...args){return window.KRNative&&typeof window.KRNative[name]==="function"?window.KRNative[name](...args):null}
function msg(t){toast.textContent=t;toast.classList.add("show");clearTimeout(msg.t);msg.t=setTimeout(()=>toast.classList.remove("show"),1600)}
function call(n=number.value.trim()){if(!n){msg("Enter a phone number");return}if(native("call",n)===null)msg("Preview mode")}
function showView(id){
  $$(".view").forEach(v=>v.classList.toggle("active",v.id===id));
  $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.view===id));
  if(id==="recentsView")loadRecents(); if(id==="contactsView")loadContacts();
}
$$(".nav-item").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
$$(".key").forEach(k=>k.addEventListener("click",()=>{number.value+=k.dataset.key;if(navigator.vibrate)navigator.vibrate(7)}));
$("#deleteBtn").addEventListener("click",()=>number.value=number.value.slice(0,-1));
$("#deleteBtn").addEventListener("contextmenu",e=>{e.preventDefault();number.value=""});
$("#clearBtn").addEventListener("click",()=>number.value="");
$("#callBtn").addEventListener("click",()=>call());
$("#themeBtn").addEventListener("click",()=>{document.documentElement.classList.toggle("dark");localStorage.setItem("theme",document.documentElement.classList.contains("dark")?"dark":"light")});
$("#settingsBtn").addEventListener("click",()=>native("requestDefaultDialer")===null&&msg("Default phone app is available in the native app"));
if(localStorage.getItem("theme")==="dark")document.documentElement.classList.add("dark");

function initials(name){return (name||"?").trim().split(/\s+/).slice(0,2).map(x=>x[0]).join("").toUpperCase()}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function loadRecents(){
 const raw=native("getRecents",50), list=$("#recentsList");
 let data=[];try{data=JSON.parse(raw||"[]")}catch{}
 if(!data.length){list.innerHTML='<div class="empty"><div><strong>No recent calls</strong>Your call history will appear here.</div></div>';return}
 list.innerHTML=data.map(x=>`<div class="item glass"><div class="avatar">${initials(x.name||x.number)}</div><div class="item-main"><div class="item-name">${esc(x.name||x.number)}</div><div class="item-sub">${esc(x.type)} · ${esc(x.time)}</div></div><button class="item-action" onclick="call('${esc(x.number)}')">☎</button></div>`).join("")
}
function loadContacts(filter=""){
 const raw=native("getContacts",300),list=$("#contactsList");let data=[];try{data=JSON.parse(raw||"[]")}catch{}
 data=data.filter(x=>(x.name+" "+x.number).toLowerCase().includes(filter.toLowerCase()));
 if(!data.length){list.innerHTML='<div class="empty"><div><strong>No contacts found</strong>Contacts saved on your phone will appear here.</div></div>';return}
 list.innerHTML=data.map(x=>`<div class="item glass"><div class="avatar">${initials(x.name)}</div><div class="item-main"><div class="item-name">${esc(x.name)}</div><div class="item-sub">${esc(x.number)}</div></div><button class="item-action" onclick="call('${esc(x.number)}')">☎</button></div>`).join("")
}
$("#refreshRecents").addEventListener("click",loadRecents);$("#refreshContacts").addEventListener("click",()=>loadContacts($("#contactSearch").value));
$("#contactSearch").addEventListener("input",e=>loadContacts(e.target.value));
