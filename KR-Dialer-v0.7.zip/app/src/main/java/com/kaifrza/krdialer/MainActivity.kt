package com.kaifrza.krdialer

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.CallLog
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    companion object {
        private const val CALL_PERMISSION_REQUEST=100
        private const val DATA_PERMISSION_REQUEST=101
        private const val DIALER_ROLE_REQUEST=200
    }
    private lateinit var webView: WebView
    private var pendingNumber:String?=null

    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        webView=WebView(this)
        webView.settings.apply {
            javaScriptEnabled=true
            domStorageEnabled=true
            allowFileAccess=true
            allowContentAccess=false
            cacheMode=WebSettings.LOAD_NO_CACHE
        }
        webView.webViewClient=WebViewClient()
        webView.addJavascriptInterface(NativeBridge(),"KRNative")
        webView.loadUrl("file:///android_asset/www/index.html")
        setContentView(webView)
    }

    override fun onResume(){
        super.onResume()
        if(CallController.getCurrentCall()!=null)
            startActivity(Intent(this,InCallActivity::class.java).apply{addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)})
    }

    private inner class NativeBridge {
        @JavascriptInterface fun call(number:String){runOnUiThread{placeCall(number)}}
        @JavascriptInterface fun requestDefaultDialer(){runOnUiThread{requestDefaultDialerRole()}}
        @JavascriptInterface fun getRecents(limit:Int):String{
            if(checkSelfPermission(Manifest.permission.READ_CALL_LOG)!=PackageManager.PERMISSION_GRANTED){
                runOnUiThread{requestDataPermissions()}; return "[]"
            }
            return readRecents(limit.coerceIn(1,100))
        }
        @JavascriptInterface fun getContacts(limit:Int):String{
            if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){
                runOnUiThread{requestDataPermissions()}; return "[]"
            }
            return readContacts(limit.coerceIn(1,500))
        }
    }

    private fun requestDataPermissions(){
        val p=mutableListOf<String>()
        if(checkSelfPermission(Manifest.permission.READ_CALL_LOG)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.READ_CALL_LOG)
        if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)p.add(Manifest.permission.READ_CONTACTS)
        if(p.isNotEmpty())ActivityCompat.requestPermissions(this,p.toTypedArray(),DATA_PERMISSION_REQUEST)
    }

    private fun placeCall(number:String){
        val clean=number.trim()
        if(clean.isEmpty())return
        if(checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){
            pendingNumber=clean;ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.CALL_PHONE),CALL_PERMISSION_REQUEST);return
        }
        getSystemService(TelecomManager::class.java).placeCall(Uri.fromParts("tel",clean,null),Bundle())
    }

    private fun requestDefaultDialerRole(){
        if(android.os.Build.VERSION.SDK_INT>=android.os.Build.VERSION_CODES.Q){
            val roleManager=getSystemService(RoleManager::class.java)
            if(roleManager.isRoleAvailable(RoleManager.ROLE_DIALER)&&!roleManager.isRoleHeld(RoleManager.ROLE_DIALER))
                startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER),DIALER_ROLE_REQUEST)
        }
    }

    private fun readRecents(limit:Int):String{
        val out=JSONArray()
        val projection=arrayOf(CallLog.Calls.NUMBER,CallLog.Calls.CACHED_NAME,CallLog.Calls.TYPE,CallLog.Calls.DATE)
        contentResolver.query(CallLog.Calls.CONTENT_URI,projection,null,null,"${CallLog.Calls.DATE} DESC")?.use{c->
            val ni=c.getColumnIndex(CallLog.Calls.NUMBER);val nn=c.getColumnIndex(CallLog.Calls.CACHED_NAME)
            val ti=c.getColumnIndex(CallLog.Calls.TYPE);val di=c.getColumnIndex(CallLog.Calls.DATE)
            var count=0
            while(c.moveToNext()&&count<limit){
                val type=when(c.getInt(ti)){CallLog.Calls.INCOMING_TYPE->"Incoming";CallLog.Calls.OUTGOING_TYPE->"Outgoing";CallLog.Calls.MISSED_TYPE->"Missed";CallLog.Calls.REJECTED_TYPE->"Rejected";else->"Call"}
                out.put(JSONObject().apply{
                    put("number",c.getString(ni)?:"");put("name",c.getString(nn)?:"")
                    put("type",type);put("time",SimpleDateFormat("dd MMM, h:mm a",Locale.getDefault()).format(Date(c.getLong(di))))
                });count++
            }
        }
        return out.toString()
    }

    private fun readContacts(limit:Int):String{
        val out=JSONArray()
        val projection=arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER)
        contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,projection,null,null,
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} COLLATE NOCASE ASC")?.use{c->
            val ni=c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);val pi=c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            val seen=HashSet<String>();var count=0
            while(c.moveToNext()&&count<limit){
                val name=c.getString(ni)?:"";val number=c.getString(pi)?:"";val key="$name|$number"
                if(number.isNotBlank()&&seen.add(key)){out.put(JSONObject().apply{put("name",name);put("number",number)});count++}
            }
        }
        return out.toString()
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==CALL_PERMISSION_REQUEST&&grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED)
            pendingNumber?.let{pendingNumber=null;placeCall(it)}
        else if(requestCode==CALL_PERMISSION_REQUEST)pendingNumber=null
    }

    override fun onDestroy(){webView.removeJavascriptInterface("KRNative");webView.destroy();super.onDestroy()}
}
