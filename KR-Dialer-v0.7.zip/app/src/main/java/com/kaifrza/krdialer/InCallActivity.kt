package com.kaifrza.krdialer

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.AudioManager
import android.os.Bundle
import android.telecom.Call
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Space
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class InCallActivity : AppCompatActivity() {

    private lateinit var callerText: TextView
    private lateinit var stateText: TextView
    private lateinit var answerButton: TextView
    private lateinit var rejectButton: TextView
    private lateinit var muteButton: TextView
    private lateinit var speakerButton: TextView
    private lateinit var endButton: TextView
    private var callback: Call.Callback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        buildUi()
        updateUi()
    }

    override fun onResume() {
        super.onResume()
        registerCurrentCallback()
        updateUi()
    }

    override fun onPause() {
        unregisterCurrentCallback()
        super.onPause()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(22), dp(22), dp(22), dp(22))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(7, 12, 18), Color.rgb(14, 27, 35))
            )
        }

        root.addView(TextView(this).apply {
            text = "KR  •  CALL"
            textSize = 11f
            letterSpacing = 0.18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(126, 226, 173))
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(40)
        ))

        val avatar = TextView(this).apply {
            text = "☎"
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = circleDrawable(Color.argb(42, 255, 255, 255), Color.argb(85, 255, 255, 255))
        }
        root.addView(avatar, LinearLayout.LayoutParams(dp(86), dp(86)).apply {
            topMargin = dp(18)
            bottomMargin = dp(16)
        })

        callerText = TextView(this).apply {
            textSize = 29f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        root.addView(callerText, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(58)
        ))

        stateText = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.rgb(164, 177, 190))
            gravity = Gravity.CENTER
        }
        root.addView(stateText)

        root.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        muteButton = actionButton("Mute")
        speakerButton = actionButton("Speaker")

        controls.addView(muteButton, controlParams())
        controls.addView(speakerButton, controlParams())
        root.addView(controls)

        val callActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        rejectButton = actionButton("Decline")
        answerButton = actionButton("Answer")

        callActions.addView(rejectButton, controlParams())
        callActions.addView(answerButton, controlParams())
        root.addView(callActions)

        root.addView(Space(this), LinearLayout.LayoutParams(1, dp(18)))

        endButton = TextView(this).apply {
            text = "END CALL"
            textSize = 13f
            letterSpacing = 0.12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = redDrawable()
            setOnClickListener { currentCall()?.disconnect() }
        }
        root.addView(endButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(62)
        ))

        muteButton.setOnClickListener {
            val audio = getSystemService(AudioManager::class.java)
            audio.isMicrophoneMute = !audio.isMicrophoneMute
            muteButton.text = if (audio.isMicrophoneMute) "Unmute" else "Mute"
        }

        speakerButton.setOnClickListener {
            val audio = getSystemService(AudioManager::class.java)
            audio.isSpeakerphoneOn = !audio.isSpeakerphoneOn
            speakerButton.text = if (audio.isSpeakerphoneOn) "Earpiece" else "Speaker"
        }

        answerButton.setOnClickListener { currentCall()?.answer(0) }
        rejectButton.setOnClickListener { currentCall()?.reject(false, null) }

        setContentView(root)
    }

    private fun actionButton(label: String): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = glassDrawable()
        }

    private fun controlParams() = LinearLayout.LayoutParams(0, dp(58), 1f).apply {
        setMargins(dp(6), dp(6), dp(6), dp(6))
    }

    private fun currentCall(): Call? = CallController.getCurrentCall()

    private fun registerCurrentCallback() {
        val call = currentCall() ?: return
        val cb = object : Call.Callback() {
            override fun onStateChanged(call: Call, state: Int) {
                runOnUiThread { updateUi() }
            }
        }
        callback = cb
        call.registerCallback(cb)
    }

    private fun unregisterCurrentCallback() {
        callback?.let { currentCall()?.unregisterCallback(it) }
        callback = null
    }

    private fun updateUi() {
        val call = currentCall()

        if (call == null) {
            callerText.text = "No active call"
            stateText.text = "Ended"
            answerButton.visibility = View.GONE
            rejectButton.visibility = View.GONE
            endButton.visibility = View.GONE
            return
        }

        callerText.text = call.details.handle?.schemeSpecificPart ?: "Unknown"

        when (call.state) {
            Call.STATE_RINGING -> {
                stateText.text = "Incoming call"
                answerButton.visibility = View.VISIBLE
                rejectButton.visibility = View.VISIBLE
                endButton.visibility = View.GONE
            }
            Call.STATE_DIALING -> {
                stateText.text = "Dialing…"
                answerButton.visibility = View.GONE
                rejectButton.visibility = View.GONE
                endButton.visibility = View.VISIBLE
            }
            Call.STATE_CONNECTING -> {
                stateText.text = "Connecting…"
                answerButton.visibility = View.GONE
                rejectButton.visibility = View.GONE
                endButton.visibility = View.VISIBLE
            }
            Call.STATE_ACTIVE -> {
                stateText.text = "Active"
                answerButton.visibility = View.GONE
                rejectButton.visibility = View.GONE
                endButton.visibility = View.VISIBLE
            }
            Call.STATE_DISCONNECTING -> {
                stateText.text = "Ending…"
                answerButton.visibility = View.GONE
                rejectButton.visibility = View.GONE
                endButton.visibility = View.GONE
            }
            Call.STATE_DISCONNECTED -> {
                stateText.text = "Call ended"
                answerButton.visibility = View.GONE
                rejectButton.visibility = View.GONE
                endButton.visibility = View.GONE
            }
            else -> stateText.text = "Connecting…"
        }
    }

    private fun glassDrawable(): RippleDrawable {
        val base = GradientDrawable().apply {
            setColor(Color.argb(43, 255, 255, 255))
            cornerRadius = dp(25).toFloat()
            setStroke(dp(1), Color.argb(70, 255, 255, 255))
        }
        return RippleDrawable(
            android.content.res.ColorStateList.valueOf(Color.argb(50, 255, 255, 255)),
            base,
            null
        )
    }

    private fun redDrawable(): RippleDrawable {
        val base = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(232, 75, 82), Color.rgb(180, 44, 53))
        ).apply {
            cornerRadius = dp(31).toFloat()
            setStroke(dp(1), Color.argb(100, 255, 255, 255))
        }
        return RippleDrawable(
            android.content.res.ColorStateList.valueOf(Color.argb(50, 255, 255, 255)),
            base,
            null
        )
    }

    private fun circleDrawable(fill: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            setStroke(dp(1), stroke)
        }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
